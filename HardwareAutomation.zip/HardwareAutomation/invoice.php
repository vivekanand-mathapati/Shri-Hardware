<?php
header("location: purchase.php");
?>