function report()
{
	var type=document.form1.type.value;
	if(type == "Sales")
	{
		var SaleReport=window.open("SaleReport.php?product="+document.form1.productList.value+'&SelectedDate='+document.form1.SelectedDate.value+'&toSelectedDate='+document.form1.toSelectedDate.value,"SaleReport","width=800,height=500");
	}else if(type == "Purchase")
	{
		var SaleReport=window.open("PurchaseReport.php?product="+document.form1.productList.value+'&SelectedDate='+document.form1.SelectedDate.value+'&toSelectedDate='+document.form1.toSelectedDate.value,"SaleReport","width=800,height=500");
	}


}
function updateSalesBalance()
{
win3 = window.open("", "win3", "width=300,height=100,resizable");
var d = win3.document;
d.open();
d.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><title>Untitled Document</title></head><body><form id="form1" name="form1" method="post" action="UpdateSalesBalance.php"><table width="360" border="1"><tr><td width="123"><label>Invoice NO.</label>&nbsp;</td><td width="221"><label><input type="text" name="invoiceno" id="invoiceno" readonly="true"/></label></td></tr><tr><td><label>Amount Paid</label>&nbsp;</td><td><input type="text" name="amtPaid"  id="amtPaid"/></td></tr><tr><td><label><input type="submit" name="Submit" value="Submit" /></label></td><td><label></label></td></tr></table></form>  </body></html>');
d.getElementById('invoiceno').value=document.form1.hiddenField.value; 
d.close();
}
function disableBalance()
{
	
	if(document.form1.hiddenField2.value == 0)
		document.getElementById('Button').disabled=true;
}
function updateBalance()
{
win3 = window.open("", "win3", "width=300,height=100,resizable");
var d = win3.document;
d.open();
d.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><title>Untitled Document</title></head><body><form id="form1" name="form1" method="post" action="purchaseInsertDB.php"><table width="360" border="1"><tr><td width="123"><label>P.O.NUMBER</label>&nbsp;</td><td width="221"><label><input type="text" name="ponumber" id="ponumber" readonly="true"/></label></td></tr><tr><td><label>Amount Paid</label>&nbsp;</td><td><input type="text" name="amtPaid"  id="amtPaid"/></td></tr><tr><td><label><input type="submit" name="Submit" value="Submit" /></label></td><td><label></label></td></tr></table></form>  </body></html>');
d.getElementById('ponumber').value=document.form1.hiddenField.value; 
d.close();
}
function addRow()
		{
			//alert("");
			/*var cnt = 0;
			var row = document.getElementById("rowToClone"); // find row to copy
			var table = document.getElementById("tableToModify"); // find table to append to
			var clone = row.cloneNode(true); // copy children too
			clone.id = "newID"; // change id or other attributes/contents
			table.appendChild(clone);// add new row to end of table */
			/*var row = document.getElementById("rowToClone");
			var clone = row.cloneNode(true);
			var appendRow =  document.createElement("</br><tr id=\"rowToClone\"><td width=\"106\" height=\"52\" ><div align=\"right\">Particulars111</div></td><td width=\"168\"><select name=\"select2\"><option>AAA</option><option>BBBB</option><option>CCCC</option></select></td><td width=\"10\">&nbsp;</td><td colspan=\"2\"><div align=\"right\">Rate/unit</div></td><td colspan=\"2\"><input name=\"textfield322\" type=\"text\" size=\"15\" /></td><td width=\"101\"><div align=\"right\">Quantity</div></td><td width=\"64\"><input name=\"textfield33\" type=\"text\" size=\"5\" /></td><td width=\"50\"><a href=\"#\"><img src=\"images/plus.gif\" alt=\"\" width=\"15\" height=\"15\" onclick=\"addRow()\"/></a></td></tr>");
			alert("");
			var table = document.getElementById("tableToModify");
			table.appendChild(clone);
			//alert("");
			/*table.innerHTML = row;
			table.style.*/
			//clone = clone + appendRow;
			//table.innerHTML = appendRow;
			//display = "inline";
			//alert("s");*/
			for (var i = 0; i < document.form1.RadioGroup1.length; i++) 
			{
					if (document.form1.RadioGroup1[i].checked) 
					{
						break
					}
			}
		
			if(window.XMLHttpRequest)
		{
			 
			 xmlHttp3=new XMLHttpRequest();
		}
		else
		{
		xmlHttp3=new ActiveXobject('Microsoft.XMLHTTP');
		}
		
		xmlHttp3.onreadystatechange = stateChange3;
		
 	xmlHttp3.open('GET','savepartDB.php?part='+document.form1.productList.value+'&rate='+document.form1.rate.value+'&quant='+document.form1.quant.value+'&ponumber='+document.form1.ponumber.value+'&date='+document.form1.SelectedDate.value+'&vendorid='+document.form1.vendorsList.value+'&vat='+document.form1.vat.value+'&amtPaid='+document.form1.amtPaid.value+'&totAmt='+document.form1.totAmt.value+'&remarks='+document.form1.remarks.value+'&ptype='+document.form1.RadioGroup1[i].value,true);
      xmlHttp3.send();
		}
function stateChange3()
{   
      if (xmlHttp3.readyState==4 || xmlHttp3.readyState=="complete")
	  {
    	      	   
    	      document.getElementById("res").innerHTML= xmlHttp3.responseText ;
			  if(xmlHttp3.responseText=="Saved Successfully")
			  {
				  var prate=parseFloat(document.form1.quant.value)*parseFloat(document.form1.rate.value);
				  var vat=(prate*parseFloat(document.getElementById('vat').value))/100;
					
					prate=prate+vat;
		
		var amt=parseFloat(document.getElementById('amtPaid').value);
		
		var amtpaid= parseFloat(prate)+parseFloat(amt);
			document.getElementById('amtPaid').value= amtpaid;
			  }
      }   
}
function Debitsales()
{
	
	
	if(window.XMLHttpRequest)
		{
			 
			 xmlHttp4=new XMLHttpRequest();
		}
		else
		{
		xmlHttp4=new ActiveXobject('Microsoft.XMLHTTP');
		}
		
		xmlHttp4.onreadystatechange = stateChange4;
		
 	xmlHttp4.open('GET','savedebitsalesDB.php?date='+document.form1.SelectedDate.value+'&invoiceno='+document.form1.invoiceno.value+'&name='+document.form1.custName.value+'&contact='+document.form1.contact.value+'&part='+document.form1.productList.value+'&rate='+document.form1.rate.value+'&quant='+document.form1.quant.value+'&vat='+document.form1.vat.value+'&totamt='+document.form1.totamt.value+'&remarks='+document.form1.remarks.value,true);
      xmlHttp4.send();
}
function stateChange4()
{   
      if (xmlHttp4.readyState==4 || xmlHttp4.readyState=="complete")
	  {
    	      	   
    	      document.getElementById("res1").innerHTML= xmlHttp4.responseText ;
			  if(xmlHttp4.responseText=="Saved Successfully")
			  {
				 	var prate=parseFloat(document.form1.quant.value)*parseFloat(document.form1.rate.value);
					var vat=(prate*parseFloat(document.getElementById('vat').value))/100;
					
					prate=prate+vat;
					var amt=parseFloat(document.getElementById('totamt').value);
		
					var amtpaid= parseFloat(prate)+parseFloat(amt);
					document.getElementById('totamt').value= amtpaid;
					document.getElementById('complete').disabled= false;
					
					var ans=confirm("You want to add another particuler?");
					if(ans==true)
					{
						
					}else
					{
						location.replace("InvoiceCreationSuccess.php?invoiceno="+document.form1.invoiceno.value);
					}
			  }
      }   
}
function creditSales()
{
	
	
	if(window.XMLHttpRequest)
		{
			 
			 xmlHttp6=new XMLHttpRequest();
		}
		else
		{
		xmlHttp6=new ActiveXobject('Microsoft.XMLHTTP');
		}
		
		xmlHttp6.onreadystatechange = stateChange6;
 	xmlHttp6.open('GET','saveCreditSalesDB.php?date='+document.form1.SelectedDate.value+'&invoiceno='+document.form1.invoiceno.value+'&amtpaid='+document.form1.amtpaid.value+'&custId='+document.form1.custId.value+'&part='+document.form1.productList.value+'&rate='+document.form1.rate.value+'&quant='+document.form1.quant.value+'&vat='+document.form1.vat.value+'&totamt='+document.form1.totamt.value+'&remarks='+document.form1.remarks.value,true);
      xmlHttp6.send();
}
function stateChange6()
{   
      if (xmlHttp6.readyState==4 || xmlHttp6.readyState=="complete")
	  {
    	      	   
    	      document.getElementById("res1").innerHTML= xmlHttp6.responseText ;
			  if(xmlHttp6.responseText=="Saved Successfully")
			  {
				  
				 	var prate=parseFloat(document.form1.quant.value)*parseFloat(document.form1.rate.value);
					var vat=(prate*parseFloat(document.getElementById('vat').value))/100;
					
					prate=prate+vat;
					var amt=parseFloat(document.getElementById('totamt').value);
		
					var amtpaid= parseFloat(prate)+parseFloat(amt);
					document.getElementById('totamt').value=parseFloat(amtpaid);
					document.getElementById('complete').disabled= false;
					
					var ans=confirm("You want to add another particuler?");
					if(ans==true)
					{
						
					}else
					{
						if(document.getElementById('amtpaid').value=="")
						{
							var ans=confirm("amount paid is NULL ...Do you want to continue?");
									if(ans==true)
								{
										location.replace("creditInvoiceCreationSuccess.php?invoiceno="+document.form1.invoiceno.value+"&amtpaid="+document.form1.amtpaid.value);
								}
								else
								{
								}
						}
						else
						{
						location.replace("creditInvoiceCreationSuccess.php?invoiceno="+document.form1.invoiceno.value+"&amtpaid="+document.form1.amtpaid.value);
						}
					}
			  }
      }   
}
function debitinvoice()
{
	location.replace("InvoiceCreationSuccess.php?invoiceno="+document.form1.invoiceno.value);
}
function creditinvoice()
{
	
	location.replace("creditInvoiceCreationSuccess.php?invoiceno="+document.form1.invoiceno.value+"&amtpaid="+document.form1.amtpaid.value);
}
function custIdFetch()
{
	
	if(window.XMLHttpRequest)
		{
			 
			 xmlHttp5=new XMLHttpRequest();
		}
		else
		{
		xmlHttp5=new ActiveXobject('Microsoft.XMLHTTP');
		}
		xmlHttp5.onreadystatechange = stateChange5;
 	xmlHttp5.open('GET','CustIdFetch.php?custName='+document.form1.customerList.value,true);
	
      xmlHttp5.send();
}
function stateChange5()
{   
      if (xmlHttp5.readyState==4 || xmlHttp5.readyState=="complete")
	  {
    	      document.getElementById("custId").value= xmlHttp5.responseText ;
		}   
}
function createRow()
		{
			var row = document.createElement('tr'); // create row node
			var col = document.createElement('td'); // create column node
			var col2 = document.createElement('td'); // create second column node
			var col3 = document.createElement('td');
			row.appendChild(col); // append first column to row
			row.appendChild(col2); // append second column to row
			row.appendChild(col3);
			col.innerHTML = "qwe"; // put data in first column
			col2.innerHTML = "rty"; // put data in second column
			col3.innerHTML = "roo";
			var table = document.getElementById("tableToModify"); // find table to append to
			table.appendChild(row); // append row to table
		}
		
function validateLogin(frm)
{
	
var user = frm.username.value;
var pass = frm.password.value;
	if(user == "" || user.trim == "")
	{
	alert("Empty Field-User Name!");
		return false;
	}
	if(pass == "" || pass.trim == "")
	{
		alert("Empty Field-Password!");
		return false;
	}
	
}

function disableAmtPaid(flag)
{

	if(flag == 1) 
	{
		document.getElementById('amtPaid').readOnly = true;
		document.getElementById('totAmt').readOnly = true;
	}
	else
	{
		document.getElementById('totAmt').readOnly = false;
	}
}

function addDate(){
	
	date = new Date();
	var month = date.getMonth()+1;
	if (month < 10) month="0" + month;
	var day = date.getDate();
	if (day < 10) day="0" + day;

	var year = date.getFullYear();
	
	document.getElementById('SelectedDate').value = year+'/'+month+'/'+day;
	
}

function addValidity() {
	var validity = document.getElementById('validity').value;
	
	if(validity != "") {
	document.getElementById('validity').value = validity+" Months";
	//alert(document.getElementById('validity').value);
	//document.getElementById('validity').readOnly = true;
	}
}

function numvalidate(e)
{
	var sText = e.value;
	var ValidChars = "0123456789.";
	var IsNumber=true;
	var Char;
	var i;
	
	
	for (i = 0; i < sText.length && IsNumber == true; i++) 
	{ 
		Char = sText.charAt(i); 
		if (ValidChars.indexOf(Char) == -1) 
		 {
		 	IsNumber = false;
		 }
	}
		if(!IsNumber)
		{
			alert('Invalid Character used, only Numbers are allowed!');
			e.value="";
			e.focus();
			e.disabled = false;
			return IsNumber;
		}
 }
 
 function contactValidate(e)
{
	var sText = e.value;
	var ValidChars = "0123456789.";
	var IsNumber=true;
	var Char;
	var i;
	
	
	for (i = 0; i < sText.length && IsNumber == true; i++) 
	{ 
		Char = sText.charAt(i); 
		if (ValidChars.indexOf(Char) == -1) 
		 {
		 	IsNumber = false;
		 }
	}
		if(!IsNumber)
		{
			alert('Invalid Character used, only Numbers are allowed!');
			e.value="";
			e.focus();
			e.disabled = false;
			return IsNumber;
		}
		if(sText.length != 10){
			alert('Invalid Phone no.!');
			e.value="";
			}
 }
 
 function amtPaidValidate(e)
{
	var sText = e.value;
	var ValidChars = "0123456789.";
	var IsNumber=true;
	var Char;
	var i;
	
	
	for (i = 0; i < sText.length && IsNumber == true; i++) 
	{ 
		Char = sText.charAt(i); 
		if (ValidChars.indexOf(Char) == -1) 
		 {
		 	IsNumber = false;
		 }
	}
		if(!IsNumber)
		{
			alert('Invalid Character used, only Numbers are allowed!');
			e.value="";
			e.focus();
			e.disabled = false;
			return IsNumber;
		}
		if(parseFloat(document.getElementById('amtpaid').value) >= parseFloat(document.getElementById('totamt').value)){
			alert('Amount paid should not exceed Total amount! ');
			e.value="";
			}
 }
 
 function purchaseAmtPaidValidate(e)
{
	var sText = e.value;
	var ValidChars = "0123456789.";
	var IsNumber=true;
	var Char;
	var i;
	
	
	for (i = 0; i < sText.length && IsNumber == true; i++) 
	{ 
		Char = sText.charAt(i); 
		if (ValidChars.indexOf(Char) == -1) 
		 {
		 	IsNumber = false;
		 }
	}
		if(!IsNumber)
		{
			alert('22Invalid Character used, only Numbers are allowed!');
			e.value="";
			e.focus();
			e.disabled = false;
			return IsNumber;
		}
		if(parseFloat(document.getElementById('amtPaid').value) <= parseFloat(document.getElementById('totAmt').value)){
			alert('Amount paid should not exceed Total amount! ');
			e.value="";
			}
 }
 
 function emailvalidate(e)
{
	//alert("LL");
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var address = e.value;
	if(reg.test(address) == false && address != "" ) 
	{
		alert('Invalid E-Mail Address');
		e.value = "";
		e.focus();
		return false;
	}
}
 
function alphavalidate(e)
{
	var alpha = e.value;
	var validchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ. ";
	var invalid = false;
	
	for(var i=0; i<alpha.length && invalid == false; i++)
	{
		var char = alpha.charAt(i);
		if(validchars.indexOf(char) == -1)
		{
			invalid = true;
			break;
		}
	}
	if(invalid)
	{
		alert('Invalid Character used, only Alphabets are allowed!');
		e.value = "";
		e.focus();
		return false;
	}
} 

function alphanumvalidate(e)
{
	var alpha = e.value;
	var validchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-";
	var invalid = false;
	
	for(var i=0; i<alpha.length && invalid == false; i++)
	{
		var char = alpha.charAt(i);
		if(validchars.indexOf(char) == -1)
		{
			invalid = true;
			break;
		}
	}
	if(invalid)
	{
		alert("Invalid Character used, only Alphabets & Numbers are allowed!");
		e.value = "";
		e.focus();
		return false;
	}
}


function editvalidity(){
	document.getElementById('validity').value = "";
	document.getElementById('validity').disabled = false;
	document.getElementById('validity').focus();
}

function disableVendorInfo(){
	
	document.getElementById('vndrid').disabled = true;
	document.getElementById('tin').disabled = true;
	document.getElementById('name').disabled = true;
	document.getElementById('address').disabled = true;
	document.getElementById('phone').disabled = true;
	document.getElementById('email').disabled = true;
}

function enableVendorDetails() {
	if(document.getElementById('edit').value == "Edit") 
	{
	document.getElementById('vndrid').disabled = false;
	document.getElementById('tin').disabled = false;
	document.getElementById('name').disabled = false;
	document.getElementById('address').disabled = false;
	document.getElementById('phone').disabled = false;
	document.getElementById('email').disabled = false;
	document.getElementById('edit').value = "Save";
	return false;
	}
}

function disableCustomerDetails() {
	document.getElementById('custid').edit= false;
	document.getElementById('name').disabled = true;
	document.getElementById('address').disabled = true;
	document.getElementById('phone').disabled = true;
	document.getElementById('email').disabled = true;
}

function enableCustomerDetails(){
	if(document.getElementById('edit').value == "Edit") 
	{
	document.getElementById('custid').edit = false;
	document.getElementById('name').disabled = false;
	document.getElementById('address').disabled = false;
	document.getElementById('phone').disabled = false;
	document.getElementById('email').disabled = false;
	document.getElementById('edit').value = "Save";
	return false;
	}
}

function disableProductDetails() {
	document.getElementById('productId').disabled =true;
	document.getElementById('name').disabled = true;
	document.getElementById('ratePerUnit').disabled = true;
	document.getElementById('description').disabled = true;
	document.getElementById('validity').disabled = true;
}

function enableProductDetails(){
	if(document.getElementById('edit').value == "Edit") 
	{
	
	document.getElementById('name').disabled = false;
	document.getElementById('ratePerUnit').disabled = false;
	document.getElementById('description').disabled = false;
	document.getElementById('validity').disabled = false;
	document.getElementById('edit').value = "Save";
	return false;
	}
}

function tinfetch(){

var vname = document.getElementById('vendorsList').value;

		if(window.XMLHttpRequest)
		{
			 
			 xmlHttp1=new XMLHttpRequest();
		}
		else
		{
		xmlHttp1=new ActiveXobject('Microsoft.XMLHTTP');
		}
		xmlHttp1.onreadystatechange = stateChange1;
 	xmlHttp1.open('GET','fetchTin.php?vendorid='+document.form1.vendorsList.value,true);
      xmlHttp1.send();
}

function stateChange1()
{   
      if (xmlHttp1.readyState==4 || xmlHttp1.readyState=="complete")
	  {
    	      	   
    	      document.getElementById("tin").value= xmlHttp1.responseText ;
    	      
    	       
    	     
         }   
}
      
	  
function ratefetch()
{



		if(window.XMLHttpRequest)
		{
			 
			 xmlHttp2=new XMLHttpRequest();
		}
		else
		{
		xmlHttp2=new ActiveXobject('Microsoft.XMLHTTP');
		}
		xmlHttp2.onreadystatechange = stateChange;
 	xmlHttp2.open('GET','fetchRate.php?particuler='+document.form1.productList.value,true);
      xmlHttp2.send();
}

function stateChange()
{   
      if (xmlHttp2.readyState==4 || xmlHttp2.readyState=="complete")
	  {
    	      	   
    	      document.getElementById("rate").value= xmlHttp2.responseText ;
	  }   
}		



function temp(){
 
 alert(document.getElementById("newID").value);

}

function validatePurchase(f)
{
	var SelectedDate = f.SelectedDate.value;
	var tin = f.tin.value;
	var ponumber = f.ponumber.value;
	var  productList= f.productList.value;
	var rate = f.rate.value;
	var quant = f.quant.value;
	var vendorsList = f.vendorsList.value;
	var amtPaid = f.amtPaid.value;
	var totAmt = f.totAmt.value;
	
	if(SelectedDate == "" || SelectedDate.trim == "")
	{
		alert("Empty Field - SelectedDate!");
		return false;
	}
	if(vendorsList == "Select Vendor ID" || vendorsList.trim == "")
	{
		alert("Empty Field - Vendor List!");
		return false;
	}
	if(tin == "" || tin.trim == "")
	{
		alert("Empty Field - TIN!");
		return false;
	}
	if(tin.length != 10)
	{
		alert("Invalid TIN!:enter 10 digit TIN");
		f.tin.value = "";
		return false;
	}
	if(ponumber == "" || ponumber.trim == "")
	{
		alert("Empty Field - PO Number!");
		return false;
	}
	
	
	if(productList == "Select Product")
	{
		alert("Empty Field - Product List!");
		return false;
	}
	if(rate == "" || rate.trim == "")
	{
		alert("Empty Field - Rate/Unit!");
		return false;
	}
	if(quant == "" || quant.trim == "")
	{
		alert("Empty Field - Quantity!");
		return false;
	}

	if(amtPaid == "0" )
	{
		alert("Transaction not yet completed!");
		return false;
	}
	
	
}

function validateCreateVendor(f)
{
	var vendid = f.vendid.value;
	var tin = f.tin.value;
	var name = f.name.value;
	var  address= f.address.value;
	var phone = f.phone.value;
	var email = f.email.value;
	
	if(vendid == "" || vendid.trim == "")
	{
		alert("Empty Field - Vendor ID!");
		return false;
	}
	if(tin == "" || tin.trim == "" )
	{
		alert("Empty Field - TIN!");
		return false;
	}
	if(tin.length != 10)
	{
		alert("Invalid TIN!:enter 10 digit TIN");
		f.tin.value = "";
		return false;
	}
	if(name == "" || name.trim == "")
	{
		alert("Empty Field - Name!");
		return false;
	}
	
	if(address == "" || address.trim == "")
	{
		alert("Empty Field - Address!");
		return false;
	}
	if(phone == "" || phone.trim == "")
	{
		alert("Empty Field - Phone Number!");
		return false;
	}
	if(phone.length != 10)
	{
		alert("Invalid Phone Number!");
		f.phone.value = "";
		return false;
	}

	if(email == "" || email.trim == "")
	{
		alert("Empty Field - E-Mail!");
		return false;
	}

}

function validateDisplayVendor(f)
{
	var vndrid = f.vndrid.value;
	var tin = f.tin.value;
	var name = f.name.value;
	var  address= f.address.value;
	var phone = f.phone.value;
	var email = f.email.value;
	
	if(vndrid == "" || vndrid.trim == "")
	{
		alert("Empty Field - Vendor ID!");
		return false;
	}
	if(tin == "" || tin.trim == "")
	{
		alert("Empty Field - TIN!");
		return false;
	}
	if(tin.length != 10)
	{
		alert("Invalid TIN!:enter 10 digit TIN");
		
		return false;
	}
	if(name == "" || name.trim == "")
	{
		alert("Empty Field - Name!");
		return false;
	}
	
	if(address == "" || address.trim == "")
	{
		alert("Empty Field - Address!");
		return false;
	}
	if(phone == "" || phone.trim == "")
	{
		alert("Empty Field - Phone Number!");
		return false;
	}
	
	if(phone.length != 10)
	{
		alert("Invalid Phone Number!");
		f.phone.value = "";
		return false;
	}

	if(email == "" || email.trim == "")
	{
		alert("Empty Field - E-Mail!");
		return false;
	}

}

function validateCreateCustomer(f)
{
	var custid = f.custid.value;
	var name = f.name.value;
	var  address= f.address.value;
	var phone = f.phone.value;
	var email = f.email.value;
	
	if(custid == "" || custid.trim == "")
	{
		alert("Empty Field - Customer ID!");
		return false;
	}
	if(name == "" || name.trim == "")
	{
		alert("Empty Field - Name!");
		return false;
	}
	
	if(address == "" || address.trim == "")
	{
		alert("Empty Field - Address!");
		return false;
	}
	if(phone == "" || phone.trim == "")
	{
		alert("Empty Field - Phone Number!");
		return false;
	}
	
	if(phone.length != 10)
	{
		alert("Invalid Phone Number!");
		f.phone.value = "";
		return false;
	}
	
	if(email == "" || email.trim == "")
	{
		alert("Empty Field - E-Mail!");
		return false;
	}
}

function validateCreateProduct(f)
{
	var prdid = f.prdid.value;
	var name = f.name.value;
	var  ratePerUnit = f.ratePerUnit.value;
	var description = f.description.value;
	var validity = f.validity.value;
	
	if(prdid == "" || prdid.trim == "")
	{
		alert("Empty Field - Product ID!");
		return false;
	}
	if(name == "" || name.trim == "")
	{
		alert("Empty Field - Name!");
		return false;
	}
	
	if(ratePerUnit == "" || ratePerUnit.trim == "")
	{
		alert("Empty Field - Rate/Unit!");
		return false;
	}
	if(description == "" || description.trim == "")
	{
		alert("Empty Field - Description!");
		return false;
	}

	if(validity == "" || validity.trim == "")
	{
		alert("Empty Field - Validity!");
		return false;
	}

}

function validateDisplayProduct(f)
{
	var prdid = f.productId.value;
	var name = f.name.value;
	var  ratePerUnit = f.ratePerUnit.value;
	var description = f.description.value;
	var validity = f.validity.value;
	
	if(prdid == "" || prdid.trim == "")
	{
		alert("Empty Field - Product ID!");
		return false;
	}
	if(name == "" || name.trim == "")
	{
		alert("Empty Field - Name!");
		return false;
	}
	
	if(ratePerUnit == "" || ratePerUnit.trim == "")
	{
		alert("Empty Field - Rate/Unit!");
		return false;
	}
	if(description == "" || description.trim == "")
	{
		alert("Empty Field - Description!");
		return false;
	}

	if(validity == "" || validity.trim == "")
	{
		alert("Empty Field - Validity!");
		return false;
	}

}

function disableProfileDetails() {
	document.getElementById('fname').disabled = true;
	document.getElementById('lname').disabled = true;
	document.getElementById('email').disabled = true;
	document.getElementById('pass').disabled = true;
	document.getElementById('cpass').disabled = true;
	document.getElementById('ans').disabled = true;
	
}

function enableProfileDetails(){
	if(document.getElementById('edit').value == "Edit") 
	{
	document.getElementById('fname').disabled = false;
	document.getElementById('lname').disabled = false;
	document.getElementById('email').disabled = false;
	document.getElementById('pass').disabled = false;
	document.getElementById('cpass').disabled = false;
	document.getElementById('ans').disabled = false;
	document.getElementById('edit').value = "Save";
	document.getElementById('pass').value = "";
	document.getElementById('cpass').value = "";
	return false;
	}
}

function validateUserRegistration(f)
{
	var fname = f.fname.value;
	var lname = f.lname.value;
	var uname = f.uname.value;
	var email = f.email.value;
	var pass = f.pass.value;
	var cpass = f.cpass.value;
	var hint = f.hint.value;
	var ans = f.ans.value;

	if(fname == "" || fname.trim == "")
	{
		alert("Empty Field - First Name!");
		return false;
	}
	if(lname == "" || lname.trim == "")
	{
		alert("Empty Field - Last Name!");
		return false;
	}
	if(uname == "" || uname.trim == "")
	{
		alert("Empty Field - User Name!");
		return false;
	}
	
	if(email == "" || email.trim == "")
	{
		alert("Empty Field - E-Mail!");
		return false;
	}
	if(pass == "" || pass.trim == "")
	{
		alert("Empty Field - Password!");
		return false;
	}
	if(cpass == "" || cpass.trim == "")
	{
		alert("Empty Field - Confirm Password!");
		return false;
	}
	if(hint == "" || hint.trim == "")
	{
		alert("Empty Field - Hint Question!");
		return false;
	}
	if(ans == "" || ans.trim == "")
	{
		alert("Empty Field - Answer!");
		return false;
	}

}

function tempaaa(){
	
alert();	
	}